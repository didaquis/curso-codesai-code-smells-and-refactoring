# Refactoring Katas

### 1. Refactoring a smelly Mars Rover's code

### 2. Refactoring classic Video Store Example

### 3. Refactoring to Hexagonal Architecture 1

### 4. Refactoring to Hexagonal Architecture 2
