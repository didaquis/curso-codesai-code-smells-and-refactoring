Smelly Mars Rover code refactoring
=============================================

Smelly Mars Rover code to practice refactoring.

We'll use it to learn to recognize some code smells
and to fix them applying some useful refactorings.