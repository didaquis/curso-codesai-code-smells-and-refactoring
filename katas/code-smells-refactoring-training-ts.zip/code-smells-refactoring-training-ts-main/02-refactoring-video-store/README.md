videostore
==========

The videostore example from Martin Fowler's Refactoring, and from Episode 3 of cleancoders.com