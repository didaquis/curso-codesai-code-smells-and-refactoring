export class DateFormatError extends Error {

    constructor() {
        super("Incorrect date format");
    }
}